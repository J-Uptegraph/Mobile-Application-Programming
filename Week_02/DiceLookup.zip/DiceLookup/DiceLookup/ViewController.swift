//
//  ViewController.swift
//  DiceLookup
//
//  Created by Johnathan Uptegraph on 9/5/22.
//

import UIKit

class ViewController: UIViewController {
        struct singleDie {
            var numSides: Int
            var faceUp: Int
    
            mutating func rollDie() {
                faceUp = Int(arc4random_uniform(UInt32(numSides))+1);
            }
        }
    var rollNickname: String = ""
    var die1 = singleDie(numSides: 6, faceUp: 0)
    var die2 = singleDie(numSides: 6, faceUp: 0)
    @IBOutlet weak var firstDieValue: UILabel!
    @IBOutlet weak var secondDieValue: UILabel!
    @IBOutlet weak var diceNickname: UILabel!
    @IBAction func rollDiceButton(_ sender: Any) {
        die1.rollDie()
        die2.rollDie()
        diceLookup()
        diceNickname.text = rollNickname
        firstDieValue.text = "1st Die: " + String(die1.faceUp)
        secondDieValue.text = "2nd Die: " + String(die2.faceUp)
    }
    
    func diceLookup(){
        if (die1.faceUp == 1){
            if(die2.faceUp == 1){
                rollNickname = "Snake Eyes"
            }
            if(die2.faceUp == 2){
                rollNickname = "Ace Caught A Deuce"
            }
            if(die2.faceUp == 3){
                rollNickname = "Easy Four"
            }
            if(die2.faceUp == 4){
                rollNickname = "Little Phoebe"
            }
            if(die2.faceUp == 5){
                rollNickname = "Sixie From Dixie"
            }
            if(die2.faceUp == 6){
                rollNickname = "The Devil"
            }
        }
            
        if (die1.faceUp == 2){
            if(die2.faceUp == 1){
                rollNickname = "Australian Yo"
            }
            if(die2.faceUp == 2){
                rollNickname = "Ballerina"
            }
            if(die2.faceUp == 3){
                rollNickname = "OJ"
            }
            if(die2.faceUp == 4){
                rollNickname = "Easy Six"
            }
            if(die2.faceUp == 5){
                rollNickname = "Skinny Dugan"
            }
            if(die2.faceUp == 6){
                rollNickname = "Easy Eight"
            }
        }

        if (die1.faceUp == 3){
            if(die2.faceUp == 1){
                rollNickname = "Little Joe From Kokomo"
            }
            if(die2.faceUp == 2){
                rollNickname = "The Fever"
            }
            if(die2.faceUp == 3){
                rollNickname = "Brooklyn Forest"
            }
            if(die2.faceUp == 4){
                rollNickname = "Skinny McKinney"
            }
            if(die2.faceUp == 5){
                rollNickname = "Easy Eight"
            }
            if(die2.faceUp == 6){
                rollNickname = "Lou Brown"
            }
        }
            
        if (die1.faceUp == 4){
            if(die2.faceUp == 1){
                rollNickname = "No Field Five"
            }
            if(die2.faceUp == 2){
                rollNickname = "Jimmy Hicks"
            }
            if(die2.faceUp == 3){
                rollNickname = "Big Red"
            }
            if(die2.faceUp == 4){
                rollNickname = "Square Pair"
            }
            if(die2.faceUp == 5){
                rollNickname = "Jesse James"
            }
            if(die2.faceUp == 6){
                rollNickname = "Tennessee"
            }
        }

        if (die1.faceUp == 5){
            if(die2.faceUp == 1){
                rollNickname = "Easy Six"
            }
            if(die2.faceUp == 2){
                rollNickname = "Benny Blue"
            }
            if(die2.faceUp == 3){
                rollNickname = "Eighter From Decatur"
            }
            if(die2.faceUp == 4){
                rollNickname = "Railroad Nine"
            }
            if(die2.faceUp == 5){
                rollNickname = "Puppy Paws"
            }
            if(die2.faceUp == 6){
                rollNickname = "Six Five No Jive"
            }
        }
    
        if (die1.faceUp == 6){
            if(die2.faceUp == 1){
                rollNickname = "Six One You're Done"
            }
            if(die2.faceUp == 2){
                rollNickname = "Easy Eight"
            }
            if(die2.faceUp == 3){
                rollNickname = "Nina From Pasadena"
            }
            if(die2.faceUp == 4){
                rollNickname = "Big One On The End"
            }
            if(die2.faceUp == 5){
                rollNickname = "Yo"
            }
            if(die2.faceUp == 6){
                rollNickname = "Midnight"
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        die1.rollDie()
        die2.rollDie()
        diceLookup()
        diceNickname.text = rollNickname
        firstDieValue.text = "Die 1 Roll: " + String(die1.faceUp)
        secondDieValue.text = "Die 2 Roll: " + String(die2.faceUp)
        
    }

}
